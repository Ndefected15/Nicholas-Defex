INSERT INTO prices (price)
VALUES (1.50),
       (2.75),
       (5.50),
       (10.25),
       (15.75);

INSERT INTO books (book_name, price)
VALUES ("The Great Gatsby", 1),
       ("Huckleberry Finn", 3),
       ("100 Years of Solitude", 5),
       ("Things Fall Apart", 1),
       ("Crime and Punishment", 2),
       ("Moby Dick",  4),
       ("Decameron", 1);
