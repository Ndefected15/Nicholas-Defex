DROP DATABASE IF EXISTS inventory_db;
CREATE DATABASE inventory_db;
