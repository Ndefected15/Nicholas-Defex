INSERT INTO books (book_name)
VALUES ("The Great Gatsby"),
       ("Huckleberry Finn"),
       ("100 Years of Solitude"),
       ("Things Fall Apart"),
       ("Crime and Punishment"),
       ("Moby Dick"),
       ("Decameron");
       
       
