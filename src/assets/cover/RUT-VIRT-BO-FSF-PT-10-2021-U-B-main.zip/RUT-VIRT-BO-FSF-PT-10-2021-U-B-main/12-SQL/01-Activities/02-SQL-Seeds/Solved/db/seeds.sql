INSERT INTO books (id, book_name)
VALUES 
  (1, "Pride and Prejudice"),
  (2,"Dracula"),
  (3,"100 Years of Solitude"),
  (4,"The Epic of Gilgamesh"),
  (5, "The Waiting Years");

INSERT INTO categories (id, category_name) 
VALUES
  (1, "Fiction"),
  (2, "Non-Fiction");

INSERT INTO prices (id, price) VALUES (1, 10.55);
