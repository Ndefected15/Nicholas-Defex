// Write code to merge two sorted arrays into a new sorted array

var mergeSorted = function (arr1, arr2) {};
