const multiplyInto20 = function(arr) {
  // TODO: Write Your Code Here
};
