// Write code to return the largest number in the given array

var maxNum = function(arr) {};
