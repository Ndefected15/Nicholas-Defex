// Currently these functions are empty. As a result, all tests will fail.
function Algo() {}

Algo.prototype.reverse = function(str) {};

Algo.prototype.isPalindrome = function(str) {};

Algo.prototype.capitalize = function(str) {};

module.exports = Algo;
