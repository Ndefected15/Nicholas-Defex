// Changed the values and operators to test if the algorithm meets all conditions
var degrees = 50; //number

var name = "jane"; //string

var isFall = true; //boolean
var isWinter = false; //boolean


var seasons = ['spring', 'summer', 'fall', 'winter'];

