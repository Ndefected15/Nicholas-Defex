console.log('Hello, loaded temperature.js');

var degreesInFahrenheight = 100;

var degreesInCelsius = (degreesInFahrenheight - 32) * (5 / 9);

console.log(degreesInCelsius);